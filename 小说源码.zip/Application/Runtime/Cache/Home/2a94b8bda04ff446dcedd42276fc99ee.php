<?php if (!defined('THINK_PATH')) exit();?>
              <!doctype html>
<html>
    
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=gbk" />
        <title><?php echo ($data["title"]); ?></title>
        <meta name="keywords" content="<?php echo ($data["keyword"]); ?>" />
        <meta name="description" content="<?php echo ($data["desc"]); ?>" />
        <link rel="stylesheet" type="text/css" href="/Public/css/biquge.css" />
        <link rel="stylesheet" type="text/css" href="/Public/css/599h.css" />
        <script type="text/javascript" src="/Public/js/jquery.min.js"></script>
        <script type="text/javascript" src="/Public/js/m.js"></script>
        <script type="text/javascript" src="/Public/js/bqg.js"></script>
        <meta name="baidu-site-verification" content="E1B2O3uMrn" />
    </head>
    
    <body>
        <div id="wrapper">

<!-- <script type="text/javascript">login();</script> -->
            <div class="header">
                <div class="header_logo">
                    <a href="/"></a>
                </div>
            </div>
            <div class="nav">
                <ul>
                    <li>
                        <a title="19楼书城" href="/">首页</a>
                    </li>
                    <?php if(is_array($data["type"])): $i = 0; $__LIST__ = $data["type"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
	                        <a href="/menu/<?php echo ($vo["name"]); ?>/"><?php echo ($vo["name"]); ?></a></li>
	                    <li><?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
            <div id="main">
                <div id="hotcontent" style=padding-top:10px;>
                    <div class="l">
                    	<?php $__FOR_START_12116__=0;$__FOR_END_12116__=5;for($i=$__FOR_START_12116__;$i < $__FOR_END_12116__;$i+=1){ ?><div class="item">
                            <div class="image">
                                <a href="/book/<?php echo $data['list_six'][$i][0]['title']; ?>/">
                                    <img src="http://www.73wx.com/files/article/image/32/32252/32252s.jpg" alt="<?php echo $data['list_six'][$i][0]['title']; ?>" width="120" height="150" /></a>
                            </div>
                            <dl>
                                <dt>
                                    <span><?php echo $data['list_six'][$i][0]['author']; ?></span>
                                    <a href="/book/<?php echo $data['list_six'][$i][0]['title']; ?>/"><?php echo $data['list_six'][$i][0]['title']; ?></a></dt>
                                <dd><?php echo $data['list_six'][$i][0]['des']; ?></dd></dl>
                            <div class="clear"></div>
                        </div><?php } ?>
                    </div>
                    <div class="r">
                        <h2>最新另类小说</h2>
                        <ul>
                        	<?php if(is_array($data["ling"])): $i = 0; $__LIST__ = $data["ling"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($i % 2 );++$i;?><li>
                                <span class="s1">[另类]</span>
                                <span class="s2">
                                    <a href="/book/<?php echo ($vo2["title"]); ?>/"><?php echo ($vo2["title"]); ?></a></span>
                                <span class="s5"><?php echo ($vo2["autor"]); ?></span>
                            </li><?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </div>
                    <div class="clear"></div>
                </div>
                <div id="newscontent">
                    <div class="l">
                        <h2>最近更新小说列表</h2>
                        <ul>
                        	<?php if(is_array($data["new"])): $i = 0; $__LIST__ = $data["new"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo3): $mod = ($i % 2 );++$i;?><li>
                                <span class="s1">[<?php echo ($vo3["name"]); ?>]</span>
                                <span class="s2">
                                    <a href="/book/<?php echo ($vo3["title"]); ?>/"><?php echo ($vo3["title"]); ?></a></span>
                                <span class="s3">
                                    <a><?php echo substr($vo3['des'],0,68); ?></a></span>
                                <span class="s4"><?php echo ($vo3["author"]); ?></span>
                                <span class="s5"><?php echo ($vo3["time"]); ?></span>
                            </li><?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </div>
                                        <div class="r">
                        <h2>最火小说</h2>
                        <ul>
                        	<?php if(is_array($data["tui"])): $i = 0; $__LIST__ = $data["tui"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo4): $mod = ($i % 2 );++$i;?><li>
                                <span class="s2">
                                    <a href="/book/<?php echo ($vo4["title"]); ?>/"><?php echo ($vo4["title"]); ?></a>
                                </span>
                                <span class="s5"><?php echo ($vo4["author"]); ?></span>
                            </li><?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
        <div id="firendlink">友情连接：
        <div class="footer">
            <div class="footer_link"></div>
            <div class="footer_cont">
                <p>19楼书城所有好看的小说为转载作品，所有好看的小说章节下载均由网友上传，转载至本站只是为了宣传本书让更多读者欣赏。</p>
                <p>Copyright 19楼书城 All Rights Reserved
                    <div style="display:none">
                        <script>show_tj();</script></div>
                </p>
            </div>
        </div>
        </div>
    </body>

</html>