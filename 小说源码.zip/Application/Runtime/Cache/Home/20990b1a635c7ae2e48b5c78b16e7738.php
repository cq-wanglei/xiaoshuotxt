<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo ($data["title"]); ?></title>
    <meta name="description" content="<?php echo ($data["keyword"]); ?>">
    <meta name="keywords" content="<?php echo ($data["desc"]); ?>">
    <meta name="robots" content="all">
    <meta name="googlebot" content="all">
    <meta name="baiduspider" content="all">
    <meta http-equiv="mobile-agent" content="format=wml; ">
    <meta http-equiv="mobile-agent" content="format=xhtml; ">
    <meta http-equiv="mobile-agent" content="format=html5; ">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta name="renderer" content="webkit" />
    <link rel="stylesheet" data-ignore="true" href="//qidian.gtimg.com/c/=/readnovel/css/lbfUI/css/icon.c9000.css,/readnovel/css/lbfUI/css/Drag.41d31.css,/readnovel/css/lbfUI/css/Checkbox.cc633.css,/readnovel/css/reset.e0c8b.css,/readnovel/css/font.db450.css,/readnovel/css/header.6206e.css,/readnovel/css/module.73d4b.css,/readnovel/css/footer.729bd.css,/readnovel/css/read.b83b6.css,/readnovel/css/layout.9f7c8.css,/readnovel/css/popup.b751d.css,/readnovel/css/book_popup.9cb94.css,/readnovel/css/vote_popup.76a80.css" />
</head>

<body class="theme-0 ">
<div class="wrap">
    <div id="j_bodyRecWrap" class="hidden"></div>
    
    
<div class="read-main-wrap font-family01" style="font-size:18px" id="j_readMainWrap">
        <div id="j_chapterBox" data-l1="3">
            
            


            
            
<div class="text-wrap" >
    <div class="main-text-wrap" >
        <div class="text-head">
            <h3 class="j_chapterName"><?php echo ($data["info"]["title"]); ?></h3>
            <div class="text-info cf">
                <div class="info fl">
                    <a href="/book/6838150503267601" target="_blank" data-bid="6838150503267601" data-auid="5292714204673701"><em class="iconfont">&#xe60c;</em><?php echo ($data["info"]["title"]); ?></a>
                    <a href="javascript:void(0);" target="_blank" data-bid="6838150503267601" data-auid="5292714204673701"><em class="iconfont">&#xe650;</em><?php echo ($data["info"]["author"]); ?></a>
                </div>
            </div>
        </div>
        <div class="read-content j_readContent">
            <?php echo ($data["maintxt"]); ?>
        </div>
        
    </div>
</div>
        </div>
        
<div class="chapter-control dib-wrap" data-l1="3">
    
    <a id="up" href="javascript:void(0);">上一章</a><span>|</span>
    <a href="javascript:void(0);" target="_blank" id="menu">目录</a><span>|</span>
    <a id="down" href="javascript:void(0);">下一章</a>
</div>
<script type="text/javascript">
    var url = window.location.href;
    var fenge1 = url.split('readbook');
    var mulu = fenge1[1].split('/');
    var shang   =   document.getElementById('up');
        shang.setAttribute('href',parseInt(mulu[2]) - 1);
    var menu     =   document.getElementById('menu');
        menu.setAttribute('href','/book/' + mulu[1] +'/');
    var xia    =   document.getElementById('down');
        xia.setAttribute('href',parseInt(mulu[2]) + 1);

</script>

</div>

</body>
</html>