<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
    	$data['title']	=		C('web_title');
    	$data['keyword'] =		C('web_keyword');
    	$data['desc'] 	=		C('web_desc');
    	$data['type']	=	M('type')->order('id asc')->select();
    	$article = M('article');
    	$data['list_six'][0] = $article->where('typeid = 1')->order('view desc')->limit(1)->select();
    	$data['list_six'][1] = $article->where('typeid = 2')->order('view desc')->limit(1)->select();
    	$data['list_six'][2] = $article->where('typeid = 3')->order('view desc')->limit(1)->select();
    	$data['list_six'][3] = $article->where('typeid = 4')->order('view desc')->limit(1)->select();
    	$data['list_six'][4] = $article->where('typeid = 5')->order('view desc')->limit(1)->select();
    	$data['list_six'][5] = $article->where('typeid = 6')->order('view desc')->limit(1)->select();
    	$data['new'] = $article->join('book_type as b on book_article.typeid = b.id')->order('time desc')->limit(25)->select();
    	$data['ling']	=	$article->where('typeid = 7')->order('id desc')->limit(9)->select();
    	$data['tui']	=	$article->order('view desc')->limit(25)->select();
    	$this->assign('data',$data);
       	$this->display();
    }

    public function menu(){
    	if (isset($_GET['id'])) {
    		$a = explode('/',$_GET['id']);
    		if ($a[0] == '排行榜') {
    			echo file_get_contents('http://127.0.0.1/index.php/home/index/erro.html');
    		}else{
    			$type = M('type')->order('id asc')->select();
    			foreach ($type as $key => $value) {
    				if ($a[0] == $value['name'] ) {
    					$data['title']	=		C('web_title');
		    			$data['keyword'] =		C('web_keyword');
		    			$data['desc'] 	=		C('web_desc');
		    			$data['type']	=	$type;
		    			$article = M('article');
		    			$data['new1'] = $article->order('time desc')->limit(6)->select();
		    			//$data['new2'] = $article->where('typeid = %d',$key + 1)->order('time desc')->limit(6,26)->select();
		    			$data['tui']	=	$article->order('view desc')->limit(25)->select();

		    			//分页
		    			$User = M('article'); // 实例化User对象
						// 进行分页数据查询 注意page方法的参数的前面部分是当前的页数使用 $_GET[p]获取
						$list = $User->where('typeid = %d',$key + 1)->order('time desc')->page($a[1].',25')->select();
						$count      = $User->where('typeid = %d',$key + 1)->count();
						$this->assign('list',$list);// 赋值数据集
						$show = '';
						//总页数
						$totalpage = ceil($count / 25);

						if ($a[1] <= '1') {
							$show = '
								<strong>当前第1页</strong>&nbsp;&nbsp;
								<a href="/menu/'.$a[0].'/'.($a[1] + 1).'/" class="ngroup">下一页</a>&nbsp;&nbsp;
								<a href="/menu/'.$a[0].'/'.$totalpage.'/" class="last">最后一页</a>';
						}else if($a[1] >= $totalpage){
							$show = '
								<a href="/menu/'.$a[0].'/1/" class="first">首页</a>&nbsp;&nbsp;
								<a href="/menu/'.$a[0].'/' .($a[1] - 1). '/" class="pgroup">上一页</a>&nbsp;&nbsp;
								<strong>当前第'.$totalpage.'页</strong>';
						}else{
							$show = '
								<a href="/menu/'.$a[0].'/1/" class="first">首页</a>&nbsp;&nbsp;
								<a href="/menu/'.$a[0].'/' .($a[1] - 1). '/" class="pgroup">上一页</a>&nbsp;&nbsp;
								<strong>当前'.$a[1].'页</strong>&nbsp;&nbsp
								<a href="/menu/'.$a[0].'/'.($a[1] + 1).'/" class="ngroup">下一页</a>&nbsp;&nbsp;
								<a href="/menu/'.$a[0].'/'.$totalpage.'/" class="last">最后一页</a>
								';
						}
						$this->assign('page',$show);// 赋值分页输出
		    			$this->assign('data',$data);
		    			$this->display();
    				}
    			}

    			if (isset($data)) {
    				# code...
    			}else{
    				echo file_get_contents('http://127.0.0.1/index.php/home/index/erro.html');
    			}
    			
    		}
    	}else{
    		echo file_get_contents('http://127.0.0.1/index.php/home/index/erro.html');
    	}
    }

    public function book(){
    	if (isset($_GET['id'])) {
    		$ss = explode('/', $_GET['id']);
    		$s = M('article')->join('book_type as t on book_article.typeid = t.id')->where("title='%s'",$ss[0])->find();
    		if (isset($s['id'])) {
    			$data['title']	=		C('web_title');
		    	$data['keyword'] =		C('web_keyword');
		    	$data['desc'] 	=		C('web_desc');
		    	$data['type']	=	M('type')->order('id asc')->select();
		    	$article = M('article');
		    	$data['info']	=	$s;
		    	$txt_dir = my_dir(C('xs_path').'/'.$ss[0]);
		    	if (@$txt_dir == '' || !isset($txt_dir)) {
		    		echo file_get_contents('http://127.0.0.1/index.php/home/index/erro.html');
		    		die();
		    	}
		    	foreach ($txt_dir as $key => $value) {
		    		$data['zhang'][] =  str_replace('.txt', '', $value);
		    	}
		    	$data['tui']	=	M('article')->order('rand()')->limit(25)->select();
		    	$this->assign('data',$data);
		    	$this->display();
    		}else{
    			echo file_get_contents('http://127.0.0.1/index.php/home/index/erro.html');
    		}
    	}
    }

    public function readbook(){
    	$url =str_replace($_SERVER['PHP_SELF'], '', $_SERVER['REQUEST_URI']);
    	$url = urldecode($url);
    	if ($url !== '') {
			$ss = explode('/', $url);
			$txt_dir = my_dir(C('xs_path').'/'.$ss[2]);
			$path = C('xs_path').'/'.$ss[2].'/'.$txt_dir[ $ss[3] - 1 ];
			$s = opentxt($path);
			if (!isset($s) || $s == '') {
				echo file_get_contents('http://127.0.0.1/index.php/home/index/erro.html');
			}else{
				$data['title']	=		C('web_title');
		    	$data['keyword'] =		C('web_keyword');
		    	$data['desc'] 	=		C('web_desc');
		    	$data['info'] = M('article')->where("title='%s'",$ss[2])->find();
		    	$data['maintxt']	=	$s;
		    	$this->assign('data',$data);
				$this->display();
			}
    	}else{
    		echo file_get_contents('http://127.0.0.1/index.php/home/index/erro.html');
    	}
    }

    public function erro(){
    	$data['web_title']	=	C('web_title');
    	$data['list'] = M('article')->order('rand()')->limit(60)->select();
    	$this->assign('data',$data);
    	$this->display();
    }
}

