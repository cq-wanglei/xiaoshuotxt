<?php if (!defined('THINK_PATH')) exit();?>  <!doctype html>
<html>
    
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=gbk" />
        <title><?php echo ($data["title"]); ?></title>
        <meta name="keywords" content="<?php echo ($data["keyword"]); ?>" />
        <meta name="description" content="<?php echo ($data["desc"]); ?>" />
        <link rel="stylesheet" type="text/css" href="/Public/css/biquge.css" />
        <link rel="stylesheet" type="text/css" href="/Public/css/599h.css" />
        <script type="text/javascript" src="/Public/js/jquery.min.js"></script>
        <script type="text/javascript" src="/Public/js/m.js"></script>
        <script type="text/javascript" src="/Public/js/bqg.js"></script>
        <meta name="baidu-site-verification" content="E1B2O3uMrn" />
    </head>
    
    <body>
        <div id="wrapper">

<!-- <script type="text/javascript">login();</script> -->
            <div class="header">
                <div class="header_logo">
                    <a href="/"></a>
                </div>
            </div>
            <div class="nav">
                <ul>
                    <li>
                        <a title="19楼书城" href="/">首页</a>
                    </li>
                    <?php if(is_array($data["type"])): $i = 0; $__LIST__ = $data["type"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
	                        <a href="/menu/<?php echo ($vo["name"]); ?>/"><?php echo ($vo["name"]); ?></a></li>
	                    <li><?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
            <div class="box_con" style="margin:14px auto 0;border-bottom:none;">
                <div class="con_top">
                    <a href="/">首页</a>&gt;&gt;
                    <a href="/menu/<?php echo ($data["info"]["name"]); ?>/"><?php echo ($data["info"]["name"]); ?></a>&gt; &gt;
                    <?php echo ($data["info"]["title"]); ?>最新章节列表
                </div>
                <div id="maininfo">
                    <div id="fmimg">
                        <a href="/book/<?php echo ($data["info"]["title"]); ?>" title="<?php echo ($data["info"]["title"]); ?>">
                            <img alt="<?php echo ($data["info"]["title"]); ?>" src="http://www.73wx.com/files/article/image/129/129726/129726s.jpg" width="120px" height="150px" /></a>
                    </div>
                    <div id="info">
                        <div class="infotitle">
                            <h1><?php echo ($data["info"]["title"]); ?></h1>
                            <i>作者：<?php echo ($data["info"]["author"]); ?></i>
                        </div>
                        <div class="intro">
                            <b>小说<?php echo ($data["info"]["author"]); ?>简介：</b>
                            <br/><?php echo ($data["info"]["des"]); ?>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <!--/info--></div>
            </div>
            <a name="body"></a>
            <div style="margin:0 auto;width:976px;border:#88c6e5 2px solid;border-top:none;border-bottom:none;">
                <table style="width:960px;">
                    <tr>
                        <td align="left" style="width:310px">
                        <td align="center" style="width:310px;">
                        <td align="right" style="width:310px;">
                    </tr>
                </table>
            </div>
            <div class="box_con" style="margin:0 auto 10px;border-top:none;">
                <div id="list">
                    <dl>
                        <dt>《<?php echo ($data["info"]["title"]); ?>》正文</dt>
                        <?php if(is_array($data["zhang"])): $i = 0; $__LIST__ = $data["zhang"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vi): $mod = ($i % 2 );++$i;?><dd>
                            <a href="/readbook/<?php echo ($data["info"]["title"]); ?>/<?php echo ($key + 1); ?>" class="f-green"><?php echo ($vi); ?></a></a>
                        </dd><?php endforeach; endif; else: echo "" ;endif; ?>
                    </dl>
                </div>
                <div class="ad_728" style="margin:10px auto;">
                    <script>mulu_liebiao_728();</script></div>
            </div>
                <div class="footer_link">&nbsp;小说推荐：
                    <?php if(is_array($data["tui"])): $i = 0; $__LIST__ = $data["tui"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><a href="/book/<?php echo ($v["title"]); ?>/" target="_blank"><?php echo ($v["title"]); ?></a><?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
<div id="firendlink">友情连接：
        <div class="footer">
            <div class="footer_link"></div>
            <div class="footer_cont">
                <p>19楼书城所有好看的小说为转载作品，所有好看的小说章节下载均由网友上传，转载至本站只是为了宣传本书让更多读者欣赏。</p>
                <p>Copyright 19楼书城 All Rights Reserved
                    <div style="display:none">
                        <script>show_tj();</script></div>
                </p>
            </div>
        </div>
        </div>
    </body>

</html>