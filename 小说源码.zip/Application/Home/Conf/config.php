<?php
return array(
	//'配置项'=>'配置值'

	'xs_path'	=>	'D:/phpStudy/WWW/xiaoshuo', //小说位置
	
);