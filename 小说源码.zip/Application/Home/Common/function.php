<?php


function my_dir($dir) {
	$dir = iconv("utf-8//ignore", "gbk", $dir);
    $files = array();
    if(@$handle = opendir($dir)) { 
        while(($file = readdir($handle)) !== false) {
        	if($file !== ".." && $file !== ".") {
        		$file = iconv("gbk", "utf-8//ignore", $file);
            	$files[] = $file;
            }
        }
        closedir($handle);
        array_multisort($files,SORT_NATURAL);
        return $files;
    }
    
}

function opentxt($file){
	$file = iconv("utf-8//ignore", "gbk", $file);
	$res = file_get_contents($file);
    $res = iconv("gbk", "utf-8//ignore", $res);
	return $res;
}
?>