<?php if (!defined('THINK_PATH')) exit();?><HTML>  
    <HEAD>
        <TITLE><?php echo ($data["web_title"]); ?> - 网站地图</TITLE>
        <META content="text/html; charset=utf-8" http-equiv=Content-Type>
        <META name=GENERATOR content="MSHTML 8.00.7601.18487"></HEAD>
        <style type="text/css">
            * {PADDING-BOTTOM: 0px;MARGIN: 0px;PADDING-LEFT: 0px;PADDING-RIGHT: 0px;FONT-SIZE: 14px;PADDING-TOP: 0px}
            BODY {TEXT-ALIGN: center;MARGIN: 0px auto;WIDTH: 960px;BACKGROUND: #f4f6f7}
            UL {TEXT-ALIGN: center;LIST-STYLE-TYPE: none;MARGIN: 0px auto}
            UL LI {BORDER-BOTTOM: #ffffff 2px solid;TEXT-ALIGN: left;BORDER-LEFT: #ffffff 2px solid;PADDING-BOTTOM: 5px;LINE-HEIGHT: 28px;MARGIN: 1px;PADDING-LEFT: 5px;WIDTH: 456px;PADDING-RIGHT: 0px;BACKGROUND: #fffacd;FLOAT: left;HEIGHT: 28px;OVERFLOW: hidden;BORDER-TOP: #ffffff 2px solid;BORDER-RIGHT: #ffffff 2px solid;PADDING-TOP: 5px;border-radius: 5px}
            UNKNOWN {BACKGROUND: #fff8dc}
            UL LI:unknown {CLEAR: right}
            UL LI:hover {BACKGROUND: #00ff00}
            A {COLOR: #000000;TEXT-DECORATION: none}
            A:hover {COLOR: #ff0000;TEXT-DECORATION: underline}
            #list {BORDER-BOTTOM: #ffffff 5px solid;BORDER-LEFT: #ffffff 5px solid;MARGIN: 10px 0px;WIDTH: 940px;BACKGROUND: #99cccc;BORDER-TOP: #ffffff 5px solid;BORDER-RIGHT: #ffffff 5px solid;border-radius: 10px}
            #list-title {PADDING-BOTTOM: 15px;MARGIN: 5px 0px;PADDING-LEFT: 0px;PADDING-RIGHT: 0px;PADDING-TOP: 15px}
            .date {float: right;color: #FF0000;padding-left: 12px;}
        </style>
    <BODY>
        <DIV id=list>
            <H1 id=list-title>
                <A href='/'><?php echo ($data["web_title"]); ?> </A>- 网站地图</H1>
            <H4>
                <A href='/'>返回首页</A>
            </H4>
            <UL>
                <?php if(is_array($data["list"])): $i = 0; $__LIST__ = $data["list"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vi): $mod = ($i % 2 );++$i;?><LI>
                    <span class="date"><?php echo date("Y-m-d"); ?></span>
                    <A title="<?php echo ($vi["title"]); ?>" href="/book/<?php echo ($vi["title"]); ?>/"><?php echo ($vi["title"]); ?></A>
                </LI><?php endforeach; endif; else: echo "" ;endif; ?>
            </UL>
        </DIV>
    </BODY>
</HTML>